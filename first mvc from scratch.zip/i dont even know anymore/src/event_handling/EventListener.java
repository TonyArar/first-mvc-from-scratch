package event_handling;

public interface EventListener {

    void onEvent(Event e);

}
