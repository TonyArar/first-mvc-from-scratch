package model;

import javax.swing.*;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Directory {

    private String path;
    private List<File> filesAndFolders;

    private DefaultListModel<String> folderListModel;

    public Directory(String path) throws Exception {
        openDirectory(path);
    }

/*
    public String getPath() {
        return path;
    }

    public List<File> getFilesAndFolders() {
        return filesAndFolders;
    }
*/

    public DefaultListModel<String> getFolderListModel() {
        return folderListModel;
    }

    public void deleteSelected() throws Exception {
        List<File> toBeDeleted = new ArrayList<>(filesAndFolders);
        toBeDeleted.removeIf(file -> !folderListModel.contains(file.getName()));
        for (File file : toBeDeleted) {
            file.delete();
        }
        refreshDirectory();
    }

    public void selectByRegex(Regex r) {
        selectEverything();
        if (r.getRegex().equals("")) {
            return;
        }
        List<String> list = new ArrayList<>();
        for (Object o : this.folderListModel.toArray()) {
            if ((r.match((String) o))) {
                list.add((String) o);
            }
        }
        this.folderListModel = new DefaultListModel<>();
        this.folderListModel.addAll(list);
    }

    private void openDirectory(String path) throws Exception {
        File directory = new File(path);
        if (!directory.exists()) {
            throw new Exception("directory doesn't exist");
        }
        File[] contents = directory.listFiles();
        this.filesAndFolders = List.of(contents);
        this.path = path;
        List<String> fileNames = Arrays.stream(contents)
                .map(x -> x.getName())
                .toList();
        this.folderListModel = new DefaultListModel<>();
        this.folderListModel.addAll(fileNames);
    }

    private void selectEverything() {
        List<String> fileNames = this.filesAndFolders.stream()
                .map(x -> x.getName())
                .toList();
        this.folderListModel = new DefaultListModel<>();
        this.folderListModel.addAll(fileNames);
    }

    private void refreshDirectory() throws Exception {
        openDirectory(this.path);
    }

}
