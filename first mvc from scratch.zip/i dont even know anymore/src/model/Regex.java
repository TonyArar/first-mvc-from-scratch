package model;

public class Regex {

    private String regex;

    public Regex(String regex) throws Exception {
        this.regex = regex;
    }

    public String getRegex() {
        return regex;
    }

    public boolean match(String input){
        if (input == null){
            return false;
        }
        return input.matches(this.regex);
    }

}
