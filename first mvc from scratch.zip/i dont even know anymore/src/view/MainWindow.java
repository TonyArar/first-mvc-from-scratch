package view;
import com.sun.tools.javac.Main;
import controllers.MainWindowController;
import event_handling.Event;
import event_handling.EventListener;
import model.Directory;
import model.Regex;


import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Objects;
import java.util.regex.PatternSyntaxException;

import javax.swing.JOptionPane;

public class MainWindow extends JFrame {

    public MainWindowController mainWindowController;

    public JPanel mainJPanel;
    public JPanel foldersJPanel;
    public JPanel textFieldsJPanel;
    public JPanel buttonsJPanel;

    public JList<String> currentFolderList;

    public JTextField folderPathTextField;
    public JTextField regexTextField;

    public JButton deleteButton;

    private EventListener folderPathConfirmedListener;
    private EventListener regexConfirmedListener;
    private EventListener deleteButtonClickedListener;

    private void initComponents(){

        mainJPanel = new JPanel();
        foldersJPanel = new JPanel();
        textFieldsJPanel = new JPanel();
        buttonsJPanel = new JPanel();

        DefaultListModel<String> initialFolderListModel = new DefaultListModel<>();
        initialFolderListModel.add(0,"hit enter to confirm your input");

        currentFolderList = new JList<>(initialFolderListModel);

        folderPathTextField = new JTextField();
        regexTextField = new JTextField();

        deleteButton = new JButton();

        // TODO
        folderPathTextField.setText("Folder Path");
        // TODO
        regexTextField.setText("Regex");

        deleteButton.setText("Delete");

    }

    private void setComponentsSizes() {
        this.setSize(450,350);
        this.setResizable(false);
        // TODO: find another way to set size, this line breaks scrolling!
        //currentFolderList.setPreferredSize(new Dimension(280,100));
        folderPathTextField.setPreferredSize(new Dimension(160,20));
        regexTextField.setPreferredSize(new Dimension(160,20));
        deleteButton.setPreferredSize(new Dimension(100,30));
    }

    private void setLayoutsAndBorders() {
        mainJPanel.setLayout(new BoxLayout(mainJPanel,BoxLayout.PAGE_AXIS));
        foldersJPanel.setLayout(new FlowLayout());
        textFieldsJPanel.setLayout(new FlowLayout());
        buttonsJPanel.setLayout(new FlowLayout());

        currentFolderList.setBorder(new TitledBorder("Current"));
    }

    private void buildComponentsHierarchy() {
        mainJPanel.add(foldersJPanel);
        mainJPanel.add(textFieldsJPanel);
        mainJPanel.add(buttonsJPanel);

        foldersJPanel.add(new JScrollPane(currentFolderList));

        textFieldsJPanel.add(folderPathTextField);
        textFieldsJPanel.add(regexTextField);

        buttonsJPanel.add(deleteButton);
    }

    private void addEventListeners(){

        folderPathConfirmedListener = new EventListener() {
            @Override
            public void onEvent(Event e) {
                System.out.println(e.getMessage());
                try {
                    // TODO: test
                    Directory directory = new Directory(folderPathTextField.getText());
                    mainWindowController.setDirectory(directory);
                } catch (Exception ex) {
                    // display message: invalid path!
                    JOptionPane.showMessageDialog(
                            MainWindow.this,
                            "Invalid Path!",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                }
            }
        };

        regexConfirmedListener = new EventListener() {
            @Override
            public void onEvent(Event e) {
                System.out.println(e.getMessage());
                try {
                    mainWindowController.setRegex(new Regex(regexTextField.getText()));
                    mainWindowController.selectByRegex();
                } catch (PatternSyntaxException ex) {
                    // display message: invalid regex!
                    JOptionPane.showMessageDialog(
                            MainWindow.this,
                            "Invalid Regex!",
                            "Error",
                            JOptionPane.ERROR_MESSAGE
                    );
                } catch (Exception ex){
                    if(Objects.equals(ex.getMessage(), "no directory selected yet!")){
                        // display message: no directory selected yet!
                        JOptionPane.showMessageDialog(
                                MainWindow.this,
                                "No Directory Selected Yet",
                                "Error",
                                JOptionPane.ERROR_MESSAGE
                        );
                    } else {
                        ex.printStackTrace();
                    }
                }
            }
        };

        deleteButtonClickedListener = new EventListener() {
            @Override
            public void onEvent(Event e) {
                // TODO: test
                int dialogResult = JOptionPane.showConfirmDialog (
                        MainWindow.this,
                        "Are You Sure?",
                        "Warning",
                        JOptionPane.YES_NO_OPTION
                );
                if(dialogResult == JOptionPane.YES_OPTION){
                    System.out.println(e.getMessage());
                    mainWindowController.deleteSelected();
                }
            }
        };

    }

    private void addSwingListeners(){

        this.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                System.exit(0);
            }
        });

        folderPathTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    folderPathConfirmedListener.onEvent(new Event("confirmed path"));
                }
            }
        });

        regexTextField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER){
                    regexConfirmedListener.onEvent(new Event("confirmed regex"));
                }
            }
        });

        deleteButton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                deleteButtonClickedListener.onEvent(new Event("clicked delete button"));
            }
        });

    }

    public MainWindow(){

        initComponents();
        setComponentsSizes();
        setLayoutsAndBorders();
        buildComponentsHierarchy();
        addEventListeners();
        addSwingListeners();

        mainWindowController = new MainWindowController(this);

        setContentPane(mainJPanel);

    }

}
