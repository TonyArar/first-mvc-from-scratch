package controllers;
import model.Directory;
import model.Regex;
import view.MainWindow;

public class MainWindowController {

    private final MainWindow mainWindow;

    private Directory directory;
    private Regex regex;

    public MainWindowController(MainWindow mainWindow) {
        this.mainWindow = mainWindow;
    }

    // set/update selected directory
    public void setDirectory(Directory directory) {
        this.directory = directory;
        setModel();
        refreshWindow();
    }

    public void setRegex(Regex regex) {
        this.regex = regex;
    }

    public void selectByRegex() throws Exception {
        try {
            this.directory.selectByRegex(this.regex);
            setModel();
        } catch (NullPointerException e){
            throw new Exception("no directory selected yet!");
        }
    }

    public void deleteSelected() {
        try {
            this.directory.deleteSelected();
            setModel();
        } catch (Exception e){
            // nothing to do here!
        }
    }

    private void setModel(){
        this.mainWindow.currentFolderList.setModel(directory.getFolderListModel());
    }

    private void refreshWindow() {
        this.mainWindow.revalidate();
        this.mainWindow.repaint();
    }

}
